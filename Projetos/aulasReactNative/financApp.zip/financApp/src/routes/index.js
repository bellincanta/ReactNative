import React from 'react'
import { View, ActivityIndicator } from "react-native";

import AuthRoutes from './auth.routes';
function Routes() {
    const loading = false; // Simulação de estado de carregamento
    const signed = false; // Simulação de estado de autenticação
  return (
    signed ? <View></View> : <AuthRoutes />
  );
}

export default Routes;